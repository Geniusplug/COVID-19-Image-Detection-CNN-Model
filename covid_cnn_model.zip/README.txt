# COVID-19 Image Detection CNN Model

## Overview
This project implements a Convolutional Neural Network (CNN) model for image detection of COVID-19 using radiography images. The model is built using TensorFlow and Keras, following a ResNet-like architecture.

## Dataset
The dataset used for training consists of chest X-ray images from four categories:
1. COVID-19
2. Lung Opacity
3. Normal
4. Viral Pneumonia

## Model Architecture
The model architecture includes:
- Convolutional layers for feature extraction
- Max pooling layers for downsampling
- Dense layers for classification

## Instructions
1. Download the dataset from Kaggle and place it in the specified directory.
2. Run the provided script to train the CNN model.
3. The trained model will be saved as `covid_cnn_model.h5`.

## Dependencies
- TensorFlow
- NumPy
- OpenCV
- scikit-learn